#include "Video.h"
#include "VideoTodoBasics.h"

/// Similar to operator+ while this operator append the next video to myself
/// usage: videoX += videoY

// TODO: implement operator += here, go to Video.h and find its declaration
// Note: in this assignment, you are not required to check the width, height and frameRate of videos









