#include "Video.h"
#include "VideoTodoBasics.h"

/// Reverse the video by reversing the order of frames, so that the frames are play from last to first
/// e.g video of sunrise become video of sunset after reverse()

// TODO: implement the member function reverse()
template <typename Frame>
void Video<Frame>::reverse()
{




}
